/*********************************************************************************** 
Purpose/Description: <This program uses a stack to determine the leader of an array. 
If there is any leader, the index of any leader is return and if no leader then -1 
is returned.>

Author�s Panther ID:  <6328318> 

Certification: I hereby certify that this work is my own and none of it is the work 
of any other person.  
***********************************************************************************/ 

import java.util.Stack;

public class Assigment1Question4 {

	//method used to find leader index
	static int leader (int[] A) {
		
		//stack used to put elements of array in for comparison
		Stack<Integer> stack = new Stack<>();
		
		//counter used to keep track of index
		int counter=0;
		
		for(int i=0; i<A.length; i++) {
			//add initial element to stack if it is empty
			if(stack.isEmpty()) {
				stack.push(i);
				
			//if the stack is not empty, we will peek the top element and compare it 
			//to the value in the array. if these are equal then we will add 1 to the 
			//counter otherwise subtract 1 from counter 
			}else if(A[stack.peek()] == A[i]) {
				counter++;
			}else {
				counter--;;
			}
			
			//if the counter becomes 0, we rest counter and stack
			if(counter==0) {
				stack.pop();
				stack.push(i);
				counter=1;
			}
		}
		
		//maxElement will keep track of the leader in the stack
		int maxElement=stack.peek();
		
		//reset counter
		counter=0; 
		
		for(int i=0; i<A.length; i++) {
			
			//check if the element at position i is equal to the array element with stack position and increment counter if true. checks if the element is a leader by comparing the array value at i and the stack value peeked
			if(A[i]==A[maxElement]) {
				counter++;
			}
			
			//returns the index of the leader tracked by maxElement
			if(A.length/2 < counter) {
				return maxElement+1;
			}
		}
		//returns -1 if no leader is found
		return -1;
	}//end method
	
	//method used to print elements of an array
	static void printArray(int[] arr) {
		
		//index variable used for comma position
		System.out.print("Array: { ");
		for(int i=0; i<arr.length; i++) {
			//last index position and no comma is printed 
			if(i==arr.length-1) {
				System.out.println(arr[i] + " }");
			//prints value of array at i
			}else{
				System.out.print(arr[i]+ ", ");
			}
		}
	}//end method 
	
	//main method for testing
	public static void main(String[] args) {
		
		int[] a = {23, 23, 67, 23, 67, 23, 45};
		//method call to print array values
		printArray(a);
		//method call to find leader position and displayed to console 
		System.out.println("A leader position: " + leader(a) + "\n");
		
		int[] b = {5,2,5,5,20};
		printArray(b);
		System.out.println("A leader position: " + leader(b) + "\n");
		
		int[] c = {-1, 2, 3, 5, 6, 6, 6, 9, 10};
		printArray(c);
		System.out.println("A leader position: " + leader(c) + "\n");
		

		int[] d = {1,2,2,6,8,2,1,2,2,2};
		printArray(d);
		System.out.println("Aleader position: " + leader(d) + "\n");

	}//end main
	
	

}//end class
