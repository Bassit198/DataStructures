/*********************************************************************************** 
Purpose/Description: <This program takes a sorted array of integer and return the 
number of occurrences of a key value. It is sub-linear because it will reduce the 
number of values in the array since we will be finding the position of the first 
occurrence and the final occurrence using binary search. Then subtract these 
positions and add 1 to get the number of occurrences>

Author�s Panther ID:  <6328318> 

Certification: I hereby certify that this work is my own and none of it is the work 
of any other person.  
***********************************************************************************/ 

public class Assignment1Question2 {
	
	//method used to find index of first value 
	public static int binarySearchFirstOccurrence(int[] array, int key, int start, int end) {
		
		//checks if the array is sorted and proceeds to calculating the mid value
		if(end >= start) {
			int mid = start + (start+end)/2;
			
			//if target value is the value in the middle, return mid value(index of target)
			if(key==array[mid]) {
				return mid;
				
			//if target value is greater than value at mid, call the method but with a starting 
				//point of mid+1 and same ending point
			}else if(key>array[mid]) {
				binarySearchFirstOccurrence(array, key, mid+1, end);
				
			//if target value is not greater than value at mid, call the method but with a 
				//same starting point and an ending point of mid-1
			}else {
				binarySearchFirstOccurrence(array, key, start, mid-1);
			}
		}
		//return -1 if array is not sorted 
		return -1;
		
	}//end method
	
	//method used to find index of last value
	public static int binarySearchLastOccurrence(int[] array, int key, int start, int end) {

		int size = array.length;
		
		//check if array is sorted then proceeds to find mid value
		if(end>=start) {
			int mid = start + (end-start)/2;
			
			//returns mid value if condition is true (index of last occurrence of target)
			if((mid==size-1 || key<array[mid+1]) && array[mid] == key) {
				return mid;
				
			//if target value is less than value at mid, call the method but with a same starting 
				//point and an ending point of mid-1
			}else if(key < array[mid]) {
				return binarySearchLastOccurrence(array, key, start, mid-1);
				
			//if target value is no less than value at mid, call the method but with a starting 
				//point of mid+1 and same ending point
			}else {
				return binarySearchLastOccurrence(array, key, mid+1, end);
			}
		}
		//return -1 if array is not sorted 
		return -1;
		
	}//end method
	
	//method used to print elements of an array
		static void printArray(int[] arr) {
			
			//index variable used for comma position
			System.out.print("Array: { ");
			for(int i=0; i<arr.length; i++) {
				//last index position and no comma is printed 
				if(i==arr.length-1) {
					System.out.println(arr[i] + " }");
				//prints value of array at i
				}else{
					System.out.print(arr[i]+ ", ");
				}
			}
		}//end method 
	
	
	public static void main(String[] args) {
		//int array of numbers to search
		int[] numbers = {-1,2,3,3,6,6,6,9,10};
		
		//method call to print array values
		printArray(numbers);
		
		//key value to check for occurrence
		int key = 6;
		//prints out target value
		System.out.println("Key: " + key);
		
		//finding the first and last occurrence key value and assigning them to ints for readability
		int first = binarySearchFirstOccurrence(numbers, key, 0, numbers.length-1);
		int last = binarySearchLastOccurrence(numbers, key, 0, numbers.length-1);
		
		//prints out number of occurrences by subtracting first occurrence position from last 
		//occurrence position since list is sorted then all key value will be next to each other. 
		//Also add one because index starts from 0. but occurrence should start from 1
		System.out.println("Number of key occurrence: " + ((last - first) + 1));

	}//end main
	
}//end class