/*********************************************************************************** 
Purpose/Description: <This program uses a recursive function to calculate a number 
raised to an exponent. If the exponent is even , a recursive call to the method is 
made with a parameter which halves n and if n is even then a recursive call to the 
method is made with a parameter of n-1. A counter is also implemented so as to count 
the number of recursive calls made.>

Author�s Panther ID:  <6328318> 

Certification: I hereby certify that this work is my own and none of it is the work 
of any other person.  
***********************************************************************************/
public class Assignment1Question3 {

	//counter variable to keep count of recursive calls
	public static long counter = 0;
	
	public static long exponentiation(long x, int n) {

		//if any number is raised to a power of 0 then will result 1
		if(n==0) {
			return 1;

		//if any number raised to the power of 1 then will result that number
		}else if(n==1) {
			return x;
			
		//if the exponent is even, recursive call is made to method with n/2 parameter
		//counter is added by 1
		//recursive call is multiplied by itself and returned
		}else if(n%2==0){
			x = exponentiation(x, n/2);
			counter++;
			return x * x;
			
		//if exponent is not even, counter is added by 1 and recursive call is made to 
		//method with parameter of n-1
		}else {
			counter++;
			return x*exponentiation(x, n-1);
		}
		
	}//end method
	
	public static void main(String[] args) {
		
		//base and exponent variable for testing
		int base = 2;
		int exp = 63;
		
		//prints out base and exponent
		System.out.println("Base: " + base);
		System.out.println("Exponent: " + exp);
		System.out.println(base + "^" + exp + " = " +exponentiation(base, exp));
		
		//prints out number of recursive calls by calling the counter variable that was 
		//used to count number of calls made
		System.out.println("Number of Multiplications: " +counter);

	}//end main

}//end class
